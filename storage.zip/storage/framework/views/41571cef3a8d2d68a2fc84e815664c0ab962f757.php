<div class="header">
			<div class="container">
				<div class="header_inner">
					<div class="header_left">
                    
						<a href="javascript:void(0)"><img class="logo-img" src="<?php echo e(Voyager::image(setting('site.logo'))); ?>"></a>
					</div>
					<div class="header_center">
                    <!-- <ul class="menu">
								<li><a href="javascript:void(0)">Heim</a></li>
								<li><a href="javascript:void(0)">Þjónusta</a></li>
								<li><a href="javascript:void(0)">Vélaleiga</a></li>
								<li><a href="javascript:void(0)">Um Castus</a></li>
							</ul>	 -->
                       <?php echo menu('main'); ?>

					</div>
					<div class="header_right">
						<a href="javascript:void(0)"><img src="<?php echo e(Voyager::image(setting('site.header_image'))); ?>"></a>
					</div>
				</div>
			</div>
		</div>	


<?php /**PATH /var/www/html/resources/views/Includes/header.blade.php ENDPATH**/ ?>