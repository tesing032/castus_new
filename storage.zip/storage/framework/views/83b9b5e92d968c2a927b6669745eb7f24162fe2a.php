

<?php $__env->startSection('content'); ?>
<?php echo $pages['body']; ?>



<?php $__env->stopSection(); ?>








<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/index.blade.php ENDPATH**/ ?>