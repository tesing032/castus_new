
<?php $__env->startSection('content'); ?>
<?php echo $page['body']; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/pages/service.blade.php ENDPATH**/ ?>